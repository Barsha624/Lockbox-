import { NextRequest, NextResponse } from "next/server";
import { S3Client, ListObjectsV2Command } from "@aws-sdk/client-s3";
import fs from "fs";
import path from "path";

const s3Client = new S3Client({
  region: process.env.AWS_REGION || "ap-southeast-2",
});

const DATA_FILE = path.join(process.cwd(), "data-cache.json");

interface CachedMeta {
  category: string;
  summary: string;
  tags: string[];
}

function getLocalCache(): Record<string, CachedMeta> {
  if (!fs.existsSync(DATA_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  } catch {
    return {};
  }
}

function saveLocalCache(data: Record<string, CachedMeta>) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const email = searchParams.get("email");

    const bucketName = process.env.AWS_S3_BUCKET_NAME || "my-new-website-demo-2026";
    const prefix = email ? `uploads/${email.replace(/[^a-zA-Z0-9-_]/g, "_")}/` : "uploads/";

    const command = new ListObjectsV2Command({
      Bucket: bucketName,
      Prefix: prefix,
    });

    const s3Data = await s3Client.send(command);
    const s3Items = s3Data.Contents || [];
    const cache = getLocalCache();

    const files = s3Items.map((item) => {
      if (!item.Key) return null;
      const name = item.Key.split("/").pop() || "";
      if (!name) return null;

      const cachedMeta = cache[item.Key] || {
        category: name.endsWith(".pdf") ? "PDFs" : name.match(/\.(jpg|jpeg|png)$/i) ? "Images" : "Documents",
        summary: `Stored in AWS S3 bucket.`,
        tags: ["S3 Object", "Cloud Vault"],
      };

      if (!cache[item.Key]) {
        cache[item.Key] = cachedMeta;
      }

      return {
        key: item.Key,
        name: name,
        size: item.Size || 0,
        lastModified: item.LastModified || new Date(),
        ...cachedMeta,
      };
    });

    saveLocalCache(cache);

    return NextResponse.json({ files: files.filter(Boolean) });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Failed to fetch files";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}