import { NextRequest, NextResponse } from "next/server";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3Client = new S3Client({
  region: process.env.AWS_REGION || "ap-southeast-2",
});

export async function POST(req: NextRequest) {
  try {
    const { fileName, fileType, userEmail } = await req.json();

    if (!fileName || !userEmail) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 });
    }

    const bucketName = process.env.AWS_S3_BUCKET_NAME || "my-new-website-demo-2026";
    
    // Sanitize the email to use safely as a folder name prefix
    const sanitizedEmail = userEmail.replace(/[^a-zA-Z0-9-_]/g, "_");
    const fileKey = `uploads/${sanitizedEmail}/${fileName}`;

    const command = new PutObjectCommand({
      Bucket: bucketName,
      Key: fileKey,
      ContentType: fileType,
    });

    // Generate a secure pre-signed upload URL valid for 1 hour
    const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });

    return NextResponse.json({ uploadUrl, fileKey });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Failed to create upload URL";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}