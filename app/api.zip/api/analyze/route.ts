import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { fileName, fileType } = await req.json();

    if (!fileName) {
      return NextResponse.json({ error: "Missing fileName" }, { status: 400 });
    }

    const nameLower = fileName.toLowerCase();
    let category = "Document";
    let tags: string[] = [];
    let summary = "";

    // Determine category and AI tags based on extension/type
    if (fileType?.startsWith("image/") || /\.(jpg|jpeg|png|gif|webp|svg)$/.test(nameLower)) {
      category = "Images";
      tags = ["Media", "Visual Asset", "S3 Storage"];
      summary = `Image file uploaded directly to S3 storage bucket.`;
    } else if (nameLower.endsWith(".pdf")) {
      category = "PDFs";
      tags = ["PDF Document", "Text Content", "Archive"];
      summary = `PDF document prepared for cloud preview and quick distribution.`;
    } else if (/\.(doc|docx|txt|md|csv|xlsx|json)$/.test(nameLower)) {
      category = "Documents";
      tags = ["Data/Text", "Structured Document", "Cloud Vault"];
      summary = `Data document indexed for full-text search and management.`;
    } else {
      category = "Other";
      tags = ["General File", "Binary Object", "S3 Storage"];
      summary = `General file object stored in AWS S3 bucket.`;
    }

    return NextResponse.json({ category, tags, summary });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Failed to analyze file";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}