import { NextRequest, NextResponse } from "next/server";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3Client = new S3Client({
  region: process.env.AWS_REGION || "ap-southeast-2",
});

export async function POST(req: NextRequest) {
  try {
    const { fileKey } = await req.json();

    if (!fileKey) {
      return NextResponse.json({ error: "Missing fileKey" }, { status: 400 });
    }

    const bucketName = process.env.AWS_S3_BUCKET_NAME || "my-new-website-demo-2026";

    const command = new GetObjectCommand({
      Bucket: bucketName,
      Key: fileKey,
    });

    // Valid for 15 minutes
    const downloadUrl = await getSignedUrl(s3Client, command, { expiresIn: 900 });

    return NextResponse.json({ downloadUrl });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Failed to generate download URL";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}